# -*- coding: utf-8 -*-

from .chrapi import CHRAPI, CHR_API_VERSION
__version__ = '.'.join([str(x) for x in CHR_API_VERSION])