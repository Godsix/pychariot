# -*- coding: utf-8 -*-

from .chrapi import CHR_API_VERSION, CHRAPI, LocalCHRAPI
__version__ = '.'.join([str(x) for x in CHR_API_VERSION])
